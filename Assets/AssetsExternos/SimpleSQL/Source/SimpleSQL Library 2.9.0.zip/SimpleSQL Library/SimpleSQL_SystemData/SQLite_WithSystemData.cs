//
// Copyright (c) 2009-2010 Krueger Systems, Inc.
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.Data;
using UnityEngine;

namespace SimpleSQL
{
	/// <summary>
	/// Represents an open connection to a SQLite database.
	/// </summary>
	public class SQLiteConnection_WithSystemData : SQLiteConnection
	{
		public SQLiteConnection_WithSystemData (string databasePath) : base(databasePath)
		{
		}
		
		public override SQLiteCommand CreateCommand (string cmdText, params object[] ps)
		{
			if (!_open) {
				throw SQLiteException.New (SQLite3.Result.Error, "Cannot create commands from unopened database");
			} else {
				var cmd = new SQLiteCommand_WithSystemData (this);
				cmd.CommandText = cmdText;
				foreach (var o in ps) {
					cmd.Bind (o);
				}
				return cmd;
			}
		}		
		
		public DataTable Query (string query, params object[] args)
		{
			var cmd = (SQLiteCommand_WithSystemData)CreateCommand(query, args);
			return ((SQLiteCommand_WithSystemData)cmd).ExecuteQuery();
		}		
	}
	
	public class SQLiteCommand_WithSystemData : SQLiteCommand
	{
		internal SQLiteCommand_WithSystemData (SQLiteConnection conn) : base(conn)
		{
		}
		
		public DataTable ExecuteQuery ()
		{
			if (_conn.Trace) 
			{
				Debug.Log("Executing Query: " + this);
			}
			
			var stmt = Prepare3 ();

            DataTable dt = new DataTable();
			DataRow dr;
			var columnCount = SQLite3.ColumnCount (stmt);
            Type columnType;

            for (int c = 0; c < columnCount; c++)
            {
                dt.Columns.Add(new DataColumn(Marshal.PtrToStringUni(SQLite3.ColumnName16(stmt, c))));
            }

            while (SQLite3.Step (stmt) == SQLite3.Result.Row) 
			{
                dr = dt.NewRow();
				
				for (int i = 0; i < columnCount; i++) 
				{
                    columnType = GetDataType(SQLite3.ColumnType(stmt, i).ToString());

                    if (columnType == typeof(Int32))
                    {
                        dr[i] = SQLite3.ColumnInt(stmt, i);
                    }
                    else if (columnType == typeof(Int64))
                    {
                        dr[i] = SQLite3.ColumnInt64(stmt, i);
                    }
                    else if (columnType == typeof(double))
                    {
                        dr[i] = SQLite3.ColumnDouble(stmt, i);
                    }
                    else if (columnType == typeof(string))
                    {
                        dr[i] = SQLite3.ColumnString(stmt, i);
                    }
                    else if (columnType == typeof(DateTime))
                    {
                        dr[i] = Convert.ToDateTime(SQLite3.ColumnString(stmt, i));
                    }
                    else if (columnType == typeof(byte[]))
                    {
                        dr[i] = SQLite3.ColumnByteArray(stmt, i);
                    }
                    else if (columnType == typeof(object))
                    {
                        dr[i] = SQLite3.ColumnString(stmt, i);
                    }
                    else
                    {
                        dr[i] = null;
                    }
				}
				
				dt.Rows.Add (dr);
			}

            Finalize(stmt);
			
			return dt;
		}

        private static Type GetDataType(string sqlColType)
        {
            sqlColType = sqlColType.Trim().ToLower();

            if (sqlColType == "integer")
            {
                return typeof(Int32);
            }
            else if (sqlColType == "bigint")
            {
                return typeof(Int64);
            }
            else if (sqlColType == "float")
            {
                return typeof(double);
            }
            else if (sqlColType.Contains("varchar"))
            {
                return typeof(string);
            }
            else if (sqlColType == "datetime")
            {
                return typeof(DateTime);
            }
            else if (sqlColType == "blob")
            {
                return typeof(byte[]);
            }
            else if (sqlColType == "text")
            {
                return typeof(string);
            }
            else if (sqlColType == "null")
            {
                return typeof(object);
            }
            else
            {
                return typeof(string);
            }
        }
	}
}
